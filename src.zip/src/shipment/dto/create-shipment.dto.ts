import { IsNotEmpty, IsString, IsOptional, IsPhoneNumber } from 'class-validator';

export class CreateShipmentDto {
  @IsString()
  @IsNotEmpty()
  trackingId: string; // Required and must be a string

  @IsPhoneNumber('EG')         // Validates international phone numbers
  @IsNotEmpty()
  phoneNumber: string;     // Must be a non-empty phone number

  @IsOptional()
  @IsString()
  description?: string;    // Optional shipment description
}
